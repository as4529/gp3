from . import laplace
from . import svi

__allowed_symbols = ['laplace', 'svi',
                     'GPLaplace', 'GPSVI']